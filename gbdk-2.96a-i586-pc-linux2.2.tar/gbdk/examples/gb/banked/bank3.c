#include "bank.h"
#pragma bank=3

void bank3(void) BANKED
{
    puts("  In bank 3!");
}

